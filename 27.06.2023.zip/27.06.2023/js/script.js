let x=10, y=30;
var z=x+y;
var a=x-y;
var b=x*y;
var c=x/y;
console.log("Sum is a ",z);
document.write("X = ",x);
document.write("<br>Y = ",y);
document.write("<br>Sum of X+Y is ",z);
document.write("<br>Subtraction of X-Y is ",a);
document.write("<br>Multiplication of X*Y is ",b);
document.write("<br>Division of X/Y is ",c);
//primitive datatype
document.write("<br><br>#Primitive Datatype");
var num=100;
var str="DARSHIT";
var BooleanVar=true;

document.write("<br>",num);
document.write("<br>",str);
document.write("<br>",BooleanVar);

document.write("<br>",typeof(BooleanVar));

//array
document.write("<br><br>#ARRAY");
var car=["BMW","Hyundai","audi"];
document.write("<br>"+car[0]);
document.write("<br>"+car[1]);
document.write("<br>"+car[2]);

let n1=10,n2=30;
var sum=n1+n2;
mul=n1*n2;
sub=n1-n2;
div=n1.n2;
mod=n1%n2;
var power=5**2;
document.write("<br>Sum:",sum+"<br>Multi:",mul+"<br>Sub:",sub+"<br>Div:",div+"<br>Modulo:",mod+"<br>Post Inc:",n1++ +"<br>Pre Inc:",++n1 +"<br>Multo:",mul+"<br>Multo:",mul)